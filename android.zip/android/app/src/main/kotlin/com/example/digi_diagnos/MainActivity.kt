package com.example.digi_diagnos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
